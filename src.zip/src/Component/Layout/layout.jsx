import React from 'react';
import Header from '../header/header';
import Content from '../content';
function Layout() {
    return (
        <React.Fragment>
            <div className="h-screen w-screen px-10 font-poppins">
                {/* ini bagian header */}
                <header className="items-center h-1/10 w-full flex">
                    <Header />
                </header>
                <main className="h-9/10 w-full flex pt-10">
                    {/* ini bagian utama */}
                    <section className="w-4/5 h-full">
                        <Content />
                    </section>
                    {/* ini bagian pesan */}
                    <section className="w-1/5 bg-green-200 h-full">2</section>
                </main>
            </div>
        </React.Fragment>
    )
}
export default Layout;
import React from "react";
import { NavLink } from "react-router-dom"
import Semua from "../img/navbar/semua.jpg"

export default function Nav() {
    const data = [
        {
            name: "Semua",
            to: "/semua",
            image: Semua,
        },
        {
            name: "Pizza",
            to: "/pizza",
            image: Semua,
        },
        {
            name: "Burger",
            to: "/burger",
            image: Semua,
        },
        {
            name: "Juz",
            to: "/juz",
            image: Semua,
        },
        {
            name: "Semua",
            to: "/semua",
            image: Semua,
        },
        {
            name: "Pizza",
            to: "/pizza",
            image: Semua,
        },
        {
            name: "Burger",
            to: "/burger",
            image: Semua,
        },
        {
            name: "Juz",
            to: "/juz",
            image: Semua,
        }
    ]
    return (
        <React.Fragment>
            <div className="mt-10 pr-5">
                <div className="flex items-center justify-between">
                    <h1 className="font-bold text-2xl">Kategori</h1>
                    <button style={{ background: '#FB6D3A' }} className="text-xs text-white rounded-2xl font-bold px-4 py-2">Lebih lengkap</button>
                </div>
                <div className="mt-3">
                    <ul className="flex justify-between w-full flex-nowrap overflow-auto">
                        {data.map((dt, index) => (
                            <li key={index} className="flex-none w-2/10 h-24 relative m-5"><img className="rounded-xl w-full h-24" src={dt.image} alt={dt.image} />
                            <NavLink to={dt.to}>
                                <p style={{ background: "rgba(1,1,1,0.5)" }} 
                                className="absolute rounded-xl h-full flex items-center justify-center top-0 bottom-0 left-0 right-0 text-white font-black">{dt.name}
                                </p>
                            </NavLink></li>
                        ))}
                    </ul>
                </div>
            </div>
        </React.Fragment>
    )
}

{/* <li className="w-64 h-28 relative">
                            <NavLink to="/Semua">
                                <img className="rounded-xl w-64 h-28" src={Semua} alt={Semua} />
                                <p style={{background:'rgba(1,1,1,0.5)'}} className="absolute rounded-xl h-full flex items-center justify-center top-0 bottom-0 left-0 right-0 text-white font-bold">Semua</p>
                            </NavLink>
                        </li>
                        <li className="w-64 h-28 relative">
                            <NavLink to="/Semua">
                                <img className="rounded-xl w-64 h-28" src={Pizza} alt={Pizza} />
                                <p style={{background:'rgba(1,1,1,0.5)'}} className="absolute rounded-xl h-full flex items-center justify-center top-0 bottom-0 left-0 right-0 text-white font-bold">Pizza</p>
                            </NavLink>
                        </li>
                        <li className="w-64 h-28 relative">
                            <NavLink to="/Semua">
                                <img className="rounded-xl w-64 h-28" src={Burger} alt={Burger} />
                                <p style={{background:'rgba(1,1,1,0.5)'}} className="absolute rounded-xl h-full flex items-center justify-center top-0 bottom-0 left-0 right-0 text-white font-bold">Burger</p>
                            </NavLink>
                        </li>
                        <li className="w-64 h-28 relative">
                            <NavLink to="/Semua">
                                <img className="rounded-xl w-64 h-28" src={Juz} alt={Juz} />
                                <p style={{background:'rgba(1,1,1,0.5)'}} className="absolute rounded-xl h-full flex items-center justify-center top-0 bottom-0 left-0 right-0 text-white font-bold">Juz</p>
                            </NavLink>
                        </li> */}